// Log to confirm script is loaded
console.log('productivity.js loaded');

// Data Fetching for Productivity
const fetchProductivityData = async () => {
    console.log('Fetching productivity data from /api/productivity_data...');
    const spinners = document.querySelectorAll('.loading-spinner');
    spinners.forEach(spinner => spinner.style.display = 'block');

    try {
        const response = await fetch('/api/productivity_data', { cache: 'no-store' });
        console.log('Response status:', response.status);
        if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
        const data = await response.json();
        console.log('Fetched data:', data);
        if (!data.metrics?.current_metrics) throw new Error('Invalid data structure: metrics.current_metrics missing');
        const metrics = data.metrics.current_metrics;

        // Populate metrics for Productivity page
        const tasksCompleted = document.getElementById('metric-tasks-completed');
        const avgCompletionTime = document.getElementById('metric-avg-completion-time');
        const efficiencyRate = document.getElementById('metric-efficiency-rate');
        const overdueTasks = document.getElementById('metric-overdue-tasks');
        if (tasksCompleted) tasksCompleted.innerHTML = `${metrics.tasks_completed} <span class="${metrics.trends.tasks_completed_trend === '↑' ? 'trend-up' : 'trend-down'}">${metrics.trends.tasks_completed_trend} (${metrics.trends.tasks_completed_percent_change?.toFixed(2) || 'N/A'}%)</span>`;
        if (avgCompletionTime) avgCompletionTime.innerHTML = `${metrics.avg_completion_time} <span class="${metrics.trends.avg_completion_time_trend === '↓' ? 'trend-up' : 'trend-down'}">${metrics.trends.avg_completion_time_trend} (${metrics.trends.avg_completion_time_percent_change?.toFixed(2) || 'N/A'}%)</span>`;
        if (efficiencyRate) efficiencyRate.innerHTML = `${metrics.efficiency_rate}% <span class="${metrics.trends.efficiency_rate_trend === '↑' ? 'trend-up' : 'trend-down'}">${metrics.trends.efficiency_rate_trend} (${metrics.trends.efficiency_rate_percent_change?.toFixed(2) || 'N/A'}%)</span>`;
        if (overdueTasks) overdueTasks.innerHTML = `${metrics.overdue_tasks} <span class="${metrics.trends.overdue_tasks_trend === '↓' ? 'trend-up' : 'trend-down'}">${metrics.trends.overdue_tasks_trend} (${metrics.trends.overdue_tasks_percent_change?.toFixed(2) || 'N/A'}%)</span>`;
        return data || { lineData: [], barData: [], areaData: [], scatterData: [], metrics: {} };
    } catch (error) {
        console.error('Error fetching productivity data:', error.message);
        alert(`Failed to load productivity data: ${error.message}. Check console for details.`);
        return {
            lineData: [],
            barData: [],
            areaData: [],
            scatterData: [],
            metrics: {
                current_metrics: {
                    tasks_completed: 0,
                    avg_completion_time: 0,
                    efficiency_rate: 0,
                    overdue_tasks: 0,
                    trends: {
                        tasks_completed_trend: '↑',
                        tasks_completed_percent_change: 0,
                        avg_completion_time_trend: '↓',
                        avg_completion_time_percent_change: 0,
                        efficiency_rate_trend: '↑',
                        efficiency_rate_percent_change: 0,
                        overdue_tasks_trend: '↓',
                        overdue_tasks_percent_change: 0
                    }
                }
            }
        };
    } finally {
        spinners.forEach(spinner => spinner.style.display = 'none');
    }
};

// Draw Charts for Productivity
const drawProductivityCharts = async () => {
    console.log('Starting to draw productivity charts...');
    const data = await fetchProductivityData();
    console.log('Data for charts:', data);
    const primaryColorStart = getCSSVariable('--chart-gradient-start');
    const primaryColorEnd = getCSSVariable('--chart-gradient-end');
    const charts = [
        { id: '#tasks-completed-chart', data: data.lineData, title: 'Tasks Completed Trend', color: primaryColorStart, colorEnd: primaryColorEnd, type: 'line' },
        { id: '#avg-completion-time-chart', data: data.barData, title: 'Avg Completion Time by Month', color: primaryColorStart, colorEnd: primaryColorEnd, type: 'bar', percentChange: data.metrics.current_metrics.trends.avg_completion_time_percent_change },
        { id: '#efficiency-rate-chart', data: data.areaData, title: 'Efficiency Rate Trend', color: primaryColorStart, colorEnd: primaryColorEnd, type: 'lollipop' }
    ];

    charts.forEach(chart => {
        console.log(`Rendering chart: ${chart.title} at ${chart.id}`);
        try {
            switch (chart.type) {
                case 'line':
                    if (typeof drawLineChart !== 'function') throw new Error('drawLineChart is not defined');
                    drawLineChart(chart.id, chart.data, chart.title, chart.color, chart.colorEnd);
                    break;
                case 'bar':
                    if (typeof drawBarChart !== 'function') throw new Error('drawBarChart is not defined');
                    drawBarChart(chart.id, chart.data, chart.title, chart.color, chart.colorEnd, chart.percentChange);
                    break;
                case 'lollipop':
                    if (typeof drawLollipopChart !== 'function') throw new Error('drawLollipopChart is not defined');
                    drawLollipopChart(chart.id, chart.data, chart.title, chart.color, chart.colorEnd);
                    break;
                default:
                    console.warn(`Unknown chart type: ${chart.type}`);
            }
        } catch (error) {
            console.error(`Error rendering chart ${chart.title}:`, error.message);
            alert(`Failed to render chart ${chart.title}: ${error.message}. Check console for details.`);
        }
    });
};

// Override drawCharts for Productivity page
const initializeProductivityCharts = () => {
    console.log('Initializing productivity charts...');
    if (typeof createTooltip !== 'function') {
        console.error('createTooltip function not found. Ensure dashboard.js is loaded correctly.');
        alert('Initialization failed: createTooltip function not available. Ensure dashboard.js is loaded.');
        return;
    }
    if (typeof getCSSVariable !== 'function') {
        console.error('getCSSVariable function not found. Ensure dashboard.js is loaded correctly.');
        alert('Initialization failed: getCSSVariable function not available. Ensure dashboard.js is loaded.');
        return;
    }
    if (typeof debounce !== 'function') {
        console.error('debounce function not found. Ensure dashboard.js is loaded correctly.');
        alert('Initialization failed: debounce function not available. Ensure dashboard.js is loaded.');
        return;
    }
    createTooltip();
    drawProductivityCharts();
};

// Check if on Productivity page and initialize
console.log('Current pathname:', window.location.pathname);
if (window.location.pathname === '/productivity') {
    console.log('Productivity page detected, setting up event listeners...');
    document.addEventListener('DOMContentLoaded', () => {
        console.log('DOMContentLoaded event fired, initializing charts...');
        initializeProductivityCharts();
    });
    window.addEventListener('resize', () => {
        console.log('Window resized, reinitializing charts...');
        debounce(initializeProductivityCharts, 150)();
    });
} else {
    console.log('Not on Productivity page, skipping initialization.');
}