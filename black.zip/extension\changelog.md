# Changelog

**Please see https://github.com/microsoft/vscode-black-formatter/releases for the latest release notes.**
