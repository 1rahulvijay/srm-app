const themes = ['light-theme', 'dark-theme', 'corporate-theme', 'neutral-theme'];
let currentTheme = localStorage.getItem('theme') || 'light-theme';
document.body.className = currentTheme;

const chartConfig = {
    defaultWidth: 350,
    defaultHeight: 240,
    margin: { top: 70, right: 30, bottom: 50, left: 30 },
    animationDuration: 6000,
    mobileBreakpoint: 1366,
    resolutions: {
        '1366': { height: 180, fontScale: 0.8 },
        '1920': { height: 240, fontScale: 1 },
        '2560': { height: 288, fontScale: 1.1 },
        '3440': { height: 312, fontScale: 1.2 },
        '3840': { height: 336, fontScale: 1.3 }
    }
};

const getCSSVariable = (variable) =>
    getComputedStyle(document.documentElement).getPropertyValue(variable).trim();

const getResponsiveDimensions = (containerId) => {
    const container = document.querySelector(containerId);
    const screenWidth = window.innerWidth;
    let width = container ? Math.max(container.clientWidth - 40, chartConfig.defaultWidth) : chartConfig.defaultWidth;
    let height = containerId === '#sankey-chart' ? window.innerHeight * 0.5 : chartConfig.defaultHeight;
    let fontScale = 1;

    for (let res in chartConfig.resolutions) {
        if (screenWidth <= parseInt(res)) {
            height = containerId !== '#sankey-chart' ? chartConfig.resolutions[res].height : height;
            fontScale = chartConfig.resolutions[res].fontScale;
            break;
        }
    }

    return { width, height, fontScale };
};

const fetchData = async () => {
    try {
        const path = window.location.pathname;
        const endpoint = path === '/productivity' ? '/api/productivity_data' :
            path === '/fte' ? '/api/fte_data' :
                path === '/sankey' ? '/api/sankey_data' :
                    '/api/data';
        const response = await fetch(endpoint, { cache: 'no-store' });
        if (!response.ok) throw new Error(`Network response was not ok: ${response.status}`);
        return await response.json();
    } catch (error) {
        console.error('Error fetching data:', error);
        return { lineData: [], barData: [], areaData: [], scatterData: [], nodes: [], links: [], metrics: { current_metrics: {} } };
    }
};

// Theme and UI Controls
function cycleTheme() {
    const index = (themes.indexOf(currentTheme) + 1) % themes.length;
    currentTheme = themes[index];
    document.body.className = currentTheme;
    localStorage.setItem('theme', currentTheme);
    refreshCharts();
}

const closeDetails = () => document.getElementById('details')?.classList.remove('open');
const switchTab = (id) => {
    document.querySelectorAll('.tab, .tab-content').forEach(el => el.classList.remove('active'));
    document.querySelector(`[onclick="switchTab('${id}')"]`)?.classList.add('active');
    document.getElementById(id)?.classList.add('active');
};

const exportToPDF = async () => {
    try {
        if (!window.jspdf?.jsPDF || !window.html2canvas) throw new Error('Required libraries not loaded');

        const { jsPDF } = window.jspdf;
        const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'tabloid' });
        const pages = [
            { path: '/', title: 'Home Dashboard' },
            { path: '/productivity', title: 'Productivity Dashboard' },
            { path: '/fte', title: 'FTE Dashboard' },
            { path: '/sankey', title: 'Sankey Dashboard' }
        ];

        for (let i = 0; i < pages.length; i++) {
            const { path, title } = pages[i];
            const iframe = document.createElement('iframe');
            iframe.style.width = '1280px';
            iframe.style.height = '720px';
            iframe.style.position = 'absolute';
            iframe.style.left = '-9999px';
            iframe.src = path;

            document.body.appendChild(iframe);
            await new Promise((resolve) => {
                iframe.onload = () => {
                    const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
                    const style = iframeDoc.createElement('style');
                    style.textContent = `
                        .theme-toggle:hover, .refresh-data:hover, button:hover { background: ${getFallbackColor(currentTheme, false)} !important; }
                        .close-details:hover { background: ${getFallbackColor(currentTheme, true)} !important; }
                    `;
                    iframeDoc.head.appendChild(style);

                    const checkCharts = setInterval(() => {
                        const charts = iframeDoc.querySelectorAll('#line-chart, #bar-chart, #area-chart, #scatter-chart, #sankey-chart');
                        if (Array.from(charts).every(c => c.innerHTML && !c.innerHTML.includes('Loading'))) {
                            clearInterval(checkCharts);
                            resolve();
                        }
                    }, 500);

                    setTimeout(() => {
                        clearInterval(checkCharts);
                        resolve();
                    }, 10000);
                };
            });

            const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
            const canvas = await html2canvas(iframeDoc.body, { scale: 2, useCORS: true });
            const imgData = canvas.toDataURL('image/png');
            const pdfWidth = doc.internal.pageSize.getWidth();
            const imgHeight = (canvas.height * pdfWidth) / canvas.width;

            if (i > 0) doc.addPage();
            doc.setFontSize(14);
            doc.text(title, 10, 10);
            doc.addImage(imgData, 'PNG', 10, 20, pdfWidth - 20, Math.min(doc.internal.pageSize.getHeight() - 30, imgHeight));

            document.body.removeChild(iframe);
        }

        doc.save('InsightDash_Dashboard.pdf');
    } catch (error) {
        console.error('Error in exportToPDF:', error);
        alert('Failed to export to PDF: ' + error.message);
    }
};

const getFallbackColor = (theme, isCloseDetails) => {
    const fallbacks = {
        'light-theme': isCloseDetails ? '#649af7' : '#5e97f8',
        'dark-theme': isCloseDetails ? '#86b7fb' : '#7db5fb',
        'corporate-theme': isCloseDetails ? '#527fed' : '#497ee9',
        'neutral-theme': isCloseDetails ? '#8c929c' : '#858b98'
    };
    return fallbacks[theme] || fallbacks['light-theme'];
};

const exportToExcel = () => {
    try {
        const rows = document.querySelectorAll('#data-table-content tr');
        if (rows.length <= 1) throw new Error('No data to export');
        const csv = [...rows].map(row => [...row.children].map(cell => `"${cell.textContent.replace(/"/g, '""')}"`).join(',')).join('\n');
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = 'dashboard_data.csv';
        link.click();
        URL.revokeObjectURL(link.href);
    } catch (error) {
        console.error('Error exporting to CSV:', error);
        alert('Failed to export to CSV. Please ensure the table has data and try again.');
    }
};

const showDetails = (data, type, summary) => {
    if (!data?.length) {
        alert('No data available to display.');
        return;
    }
    const container = document.getElementById('details');
    if (!container) return;
    if (container.classList.contains('open')) {
        container.classList.remove('open');
        return;
    }
    document.getElementById('overview-text').textContent = summary;
    const tableBody = document.querySelector('#data-table-content tbody');
    if (tableBody) {
        tableBody.innerHTML = data.map(d => `<tr><td>${d.label || 'N/A'}</td><td>${type === 'scatter' ? `TF: ${d.total_tf?.toFixed(2) || 'N/A'}, OCM: ${d.ocm_overall?.toFixed(2) || 'N/A'}` : `${(d.value ?? 'N/A').toFixed(2)}`}</td></tr>`).join('');
    }
    switchTab('data-table');
    container.classList.add('open');
};

let isRendering = false;

const drawCharts = async () => {
    if (isRendering) return;
    isRendering = true;
    try {
        const data = await fetchData();
        const primaryColorStart = getCSSVariable('--chart-gradient-start');
        const primaryColorEnd = getCSSVariable('--chart-gradient-end');

        const chartConfigs = {
            '/': [
                { id: '#line-chart', data: data.lineData, title: 'ID Count Trend', color: primaryColorStart, type: 'line' },
                { id: '#bar-chart', data: data.barData, title: 'GF Count by Month', color: primaryColorStart, type: 'bar' },
                { id: '#area-chart', data: data.areaData, title: 'GFC Count Trend', color: primaryColorStart, type: 'lollipop' },
                { id: '#scatter-chart', data: data.scatterData, title: 'ID Distribution', colors: ['#ff5555', '#5555ff'], type: 'scatter' }
            ],
            '/productivity': [
                { id: '#line-chart', data: data.lineData, title: 'Tasks Completed Trend', color: primaryColorStart, type: 'line' },
                { id: '#bar-chart', data: data.barData, title: 'Avg Completion Time by Month', color: primaryColorStart, type: 'bar' },
                { id: '#area-chart', data: data.areaData, title: 'Efficiency Rate Trend', color: primaryColorStart, type: 'lollipop' }
            ],
            '/fte': [
                { id: '#line-chart', data: data.lineData, title: 'Total FTE Trend', color: primaryColorStart, type: 'line' },
                { id: '#bar-chart', data: data.barData, title: 'Utilization by Month', color: primaryColorStart, type: 'bar' },
                { id: '#area-chart', data: data.areaData, title: 'Overtime Hours Trend', color: primaryColorStart, type: 'lollipop' }
            ],
            '/sankey': [
                { id: '#sankey-chart', data, title: 'Client Flow Sankey Diagram', color: primaryColorStart, type: 'sankey' }
            ]
        };

        const charts = chartConfigs[window.location.pathname] || chartConfigs['/'];
        const chartCount = charts.length;

        // Dynamically adjust chart grid
        const chartGrid = document.querySelector('.chart-grid');
        if (chartGrid) {
            chartGrid.innerHTML = '';
            chartGrid.className = 'chart-grid';
            if (chartCount === 4) {
                chartGrid.style.gridTemplateColumns = 'repeat(2, 1fr)';
            } else if (chartCount === 3) {
                chartGrid.style.gridTemplateColumns = '1fr 1fr';
                chartGrid.style.gridTemplateRows = '1fr 1fr';
                chartGrid.style.gridTemplateAreas = '"chart1 chart2" "chart3 chart3"';
            } else if (chartCount === 1) {
                chartGrid.style.gridTemplateColumns = '1fr';
                chartGrid.style.gridTemplateRows = '1fr';
                chartGrid.style.height = '100vh';
            }

            charts.forEach((chart, index) => {
                const container = document.createElement('div');
                container.id = chart.id.replace('#', '');
                container.className = 'card';
                if (chartCount === 3 && index === 2) {
                    container.style.gridArea = 'chart3';
                } else if (chartCount === 4) {
                    container.style.gridArea = `chart${index + 1}`;
                }
                chartGrid.appendChild(container);
            });
        }

        ['#line-chart', '#bar-chart', '#area-chart', '#scatter-chart', '#sankey-chart'].forEach(selector => {
            const container = document.querySelector(selector);
            if (container) container.innerHTML = '';
        });

        for (const chart of charts) {
            try {
                const container = document.querySelector(chart.id);
                if (!container) continue;

                switch (chart.type) {
                    case 'line': drawLineChart(chart.id, chart.data, chart.title, chart.color, primaryColorEnd); break;
                    case 'bar': drawBarChart(chart.id, chart.data, chart.title, chart.color, primaryColorEnd, 0); break;
                    case 'lollipop': drawLollipopChart(chart.id, chart.data, chart.title, chart.color, primaryColorEnd); break;
                    case 'scatter': drawScatterChart(chart.id, chart.data, chart.title, chart.colors[0], chart.colors[1]); break;
                    case 'sankey': drawSankeyChart(chart.id, chart.data, chart.title, chart.color); break;
                }
            } catch (error) {
                console.error(`Error rendering chart ${chart.title}:`, error);
                document.querySelector(chart.id).innerHTML = `<div class="error">Error loading chart</div>`;
            }
        }
    } finally {
        isRendering = false;
    }
};

const refreshCharts = async () => {
    if (isRendering) return;
    ['#line-chart', '#bar-chart', '#area-chart', '#scatter-chart', '#sankey-chart'].forEach(selector => {
        const container = document.querySelector(selector);
        if (container) container.innerHTML = '';
    });
    drawCharts();
};

// Optimized chart drawing functions (simplified for brevity, full versions remain similar)
const drawLineChart = (container, data, title, color, colorEnd) => {
    if (!data?.length) {
        d3.select(container).append('text').attr('x', '50%').attr('y', '50%').attr('text-anchor', 'middle').attr('fill', getCSSVariable('--fg')).text('No data');
        return;
    }
    const { width, height, fontScale } = getResponsiveDimensions(container);
    const svg = d3.select(container).append('svg').attr('viewBox', `0 0 ${width} ${height}`);
    const { margin } = chartConfig;
    const x = d3.scalePoint().domain(data.map(d => d.label)).range([margin.left, width - margin.right]);
    const y = d3.scaleLinear().domain([0, d3.max(data, d => d.value) * 1.2]).range([height - margin.bottom, margin.top]);

    createChartBase(svg, width, height, x, y, fontScale);
    createEffects(svg);
    const gradientId = `lineGradient-${Math.random().toString(36).substr(2, 9)}`;
    const fill = createGradient(svg, gradientId, color, colorEnd);

    const line = d3.line().x(d => x(d.label)).y(d => y(d.value)).curve(d3.curveMonotoneX);
    svg.append('path').datum(data).attr('stroke', color).attr('stroke-width', 2).attr('fill', 'none').attr('d', line)
        .attr('stroke-dasharray', d => d.totalLength).attr('stroke-dashoffset', d => d.totalLength)
        .transition().duration(2000).attr('stroke-dashoffset', 0);

    svg.selectAll('circle').data(data).enter().append('circle')
        .attr('cx', d => x(d.label)).attr('cy', d => y(d.value)).attr('r', 4).attr('fill', color)
        .attr('stroke', '#fff').attr('stroke-width', 1).style('cursor', 'pointer')
        .on('mouseover', (event, d) => {
            d3.select('.tooltip').style('display', 'block').html(`<b>${d.label}</b><br>Value: ${d.value}`).style('left', `${event.pageX + 10}px`).style('top', `${event.pageY - 40}px`).style('opacity', 0.9);
        }).on('mouseout', () => d3.select('.tooltip').style('opacity', 0).style('display', 'none'));

    createLegend(svg, width, color, title.split(' ')[0], fontScale);
    svg.on('click', () => showDetails(data, 'line', `Trend of ${title} over time.`));
};

const drawBarChart = (container, data, title, color, colorEnd, percentChange) => {
    if (!data?.length) {
        d3.select(container).append('text').attr('x', '50%').attr('y', '50%').attr('text-anchor', 'middle').attr('fill', getCSSVariable('--fg')).text('No data');
        return;
    }
    const { width, height, fontScale } = getResponsiveDimensions(container);
    const svg = d3.select(container).append('svg').attr('viewBox', `0 0 ${width} ${height}`);
    const { margin } = chartConfig;
    const x = d3.scaleBand().domain(data.map(d => d.label)).range([margin.left, width - margin.right]).padding(0.1);
    const y = d3.scaleLinear().domain([0, d3.max(data, d => d.value) * 1.2]).range([height - margin.bottom, margin.top]);

    createChartBase(svg, width, height, x, y, fontScale);
    createEffects(svg);
    const gradientId = `barGradient-${Math.random().toString(36).substr(2, 9)}`;
    const fill = createGradient(svg, gradientId, color, colorEnd);

    svg.selectAll('rect').data(data).enter().append('rect')
        .attr('x', d => x(d.label)).attr('y', d => y(0)).attr('width', x.bandwidth()).attr('height', 0)
        .attr('fill', fill).attr('rx', 4).style('cursor', 'pointer')
        .transition().duration(2000).attr('y', d => y(d.value)).attr('height', d => height - margin.bottom - y(d.value));

    createLegend(svg, width, color, title.split(' ')[0], fontScale);
    svg.on('click', () => showDetails(data, 'bar', `Distribution of ${title}. % Change: ${percentChange?.toFixed(2) || 'N/A'}%`));
};

const drawLollipopChart = (container, data, title, color, colorEnd) => {
    if (!data?.length) {
        d3.select(container).append('text').attr('x', '50%').attr('y', '50%').attr('text-anchor', 'middle').attr('fill', getCSSVariable('--fg')).text('No data');
        return;
    }
    const { width, height, fontScale } = getResponsiveDimensions(container);
    const svg = d3.select(container).append('svg').attr('viewBox', `0 0 ${width} ${height}`);
    const { margin } = chartConfig;
    const x = d3.scalePoint().domain(data.map(d => d.label)).range([margin.left, width - margin.right]).padding(0.5);
    const y = d3.scaleLinear().domain([0, d3.max(data, d => d.value) * 1.2]).range([height - margin.bottom, margin.top]);

    createChartBase(svg, width, height, x, y, fontScale);
    createEffects(svg);

    svg.selectAll('line').data(data).enter().append('line')
        .attr('x1', d => x(d.label)).attr('x2', d => x(d.label)).attr('y1', y(0)).attr('y2', y(0))
        .attr('stroke', color).attr('stroke-width', 2)
        .transition().duration(2000).attr('y2', d => y(d.value));

    svg.selectAll('circle').data(data).enter().append('circle')
        .attr('cx', d => x(d.label)).attr('cy', y(0)).attr('r', 0).attr('fill', color)
        .attr('stroke', '#fff').attr('stroke-width', 1).style('cursor', 'pointer')
        .transition().duration(2000).attr('cy', d => y(d.value)).attr('r', 4);

    createLegend(svg, width, color, title.split(' ')[0], fontScale);
    svg.on('click', () => showDetails(data, 'grouped-bar', `Trend of ${title} over time.`));
};

const drawScatterChart = (container, data, title, colorTF, colorOCM) => {
    if (!data?.length) {
        d3.select(container).append('text').attr('x', '50%').attr('y', '50%').attr('text-anchor', 'middle').attr('fill', getCSSVariable('--fg')).text('No data');
        return;
    }
    const { width, height, fontScale } = getResponsiveDimensions(container);
    const svg = d3.select(container).append('svg').attr('viewBox', `0 0 ${width} ${height}`);
    const { margin } = chartConfig;
    const x = d3.scalePoint().domain(data.map(d => d.label)).range([margin.left, width - margin.right]);
    const yTF = d3.scaleLinear().domain([0, d3.max(data, d => d.total_tf || 0) * 1.2]).range([height - margin.bottom, margin.top]);
    const yOCM = d3.scaleLinear().domain([0, d3.max(data, d => d.ocm_overall || 0) * 1.2]).range([height - margin.bottom, margin.top]);

    createChartBase(svg, width, height, x, yTF, fontScale);
    svg.append('g').attr('class', 'y-axis').attr('transform', `translate(${width - margin.right}, 0)`).call(d3.axisRight(yOCM));
    createEffects(svg);

    const lineTF = d3.line().x(d => x(d.label)).y(d => yTF(d.total_tf || 0));
    const lineOCM = d3.line().x(d => x(d.label)).y(d => yOCM(d.ocm_overall || 0));

    svg.append('path').datum(data).attr('stroke', colorTF).attr('stroke-width', 2).attr('fill', 'none').attr('d', lineTF);
    svg.append('path').datum(data).attr('stroke', colorOCM).attr('stroke-width', 2).attr('fill', 'none').attr('d', lineOCM);

    svg.selectAll('.dot-tf').data(data).enter().append('circle')
        .attr('cx', d => x(d.label)).attr('cy', d => yTF(d.total_tf || 0)).attr('r', 4).attr('fill', colorTF)
        .attr('stroke', '#fff').attr('stroke-width', 1).style('cursor', 'pointer');
    svg.selectAll('.dot-ocm').data(data).enter().append('circle')
        .attr('cx', d => x(d.label)).attr('cy', d => yOCM(d.ocm_overall || 0)).attr('r', 4).attr('fill', colorOCM)
        .attr('stroke', '#fff').attr('stroke-width', 1).style('cursor', 'pointer');

    createScatterLegend(svg, width, [colorTF, colorOCM], fontScale);
    svg.on('click', () => showDetails(data, 'scatter', `Distribution of ${title} over time.`));
};

const drawSankeyChart = (containerId, data, title, color) => {
    if (!data?.nodes?.length || !data?.links?.length) {
        d3.select(containerId).append('text').attr('x', '50%').attr('y', '50%').attr('text-anchor', 'middle').style('fill', getCSSVariable('--fg')).text('No data');
        return;
    }
    const { width, height, fontScale } = getResponsiveDimensions(containerId);
    const svg = d3.select(containerId).append('svg').attr('viewBox', `0 0 ${width} ${height}`).style('width', '100%').style('height', '100%');
    const { margin } = chartConfig;
    const sankey = d3.sankey().nodeWidth(20).nodePadding(10).extent([[margin.left, margin.top], [width - margin.right, height - margin.bottom]]);
    const sankeyData = sankey({ nodes: data.nodes.map((d, i) => ({ ...d, id: i })), links: data.links.map(d => ({ ...d })) });

    createEffects(svg);
    const gradientId = `sankey-link-gradient-${Math.random().toString(36).substr(2, 9)}`;
    createGradient(svg, gradientId, getCSSVariable('--chart-gradient-start'), getCSSVariable('--chart-gradient-end'));

    svg.append('g').attr('class', 'links').selectAll('path').data(sankeyData.links).enter().append('path')
        .attr('d', d3.sankeyLinkHorizontal()).attr('stroke', `url(#${gradientId})`).attr('stroke-width', d => d.width)
        .attr('fill', 'none').attr('stroke-opacity', 0.5).on('mouseover', (event, d) => {
            d3.select('.tooltip').style('display', 'block').html(`<b>${d.source.name} → ${d.target.name}</b><br>Value: ${d.value}`).style('left', `${event.pageX + 10}px`).style('top', `${event.pageY - 40}px`).style('opacity', 0.9);
        }).on('mouseout', () => d3.select('.tooltip').style('opacity', 0).style('display', 'none'));

    const node = svg.append('g').attr('class', 'nodes').selectAll('g').data(sankeyData.nodes).enter().append('g');
    node.append('rect').attr('x', d => d.x0).attr('y', d => d.y0).attr('height', d => d.y1 - d.y0).attr('width', d => d.x1 - d.x0)
        .attr('fill', color).attr('stroke', '#fff').style('opacity', 0).transition().duration(600).style('opacity', 1);
    node.append('text').attr('x', d => d.x0 < width / 2 ? 28 : -8).attr('y', d => (d.y1 - d.y0) / 2).attr('dy', '0.35em')
        .attr('text-anchor', d => d.x0 < width / 2 ? 'start' : 'end').text(d => d.name).style('fill', getCSSVariable('--fg'));

    svg.append('text').attr('x', width / 2).attr('y', margin.top / 2).attr('text-anchor', 'middle').style('fill', getCSSVariable('--fg'))
        .style('font-size', `${14 * fontScale}px`).text(title).style('opacity', 0).transition().duration(800).style('opacity', 1);

    svg.on('click', () => showDetails(sankeyData.links.map(d => ({ label: `${d.source.name} → ${d.target.name}`, value: d.value })), 'sankey', `Flow from ${title}`));
};

const createChartBase = (svg, width, height, x, y, fontScale) => {
    const { margin } = chartConfig;
    svg.append('g').attr('class', 'grid').attr('transform', `translate(0, ${height - margin.bottom})`).call(d3.axisBottom(x).tickSize(-height + margin.top + margin.bottom).tickFormat(''));
    svg.append('g').attr('class', 'grid').attr('transform', `translate(${margin.left}, 0)`).call(d3.axisLeft(y).tickSize(-width + margin.left + margin.right).tickFormat(''));
    svg.append('g').attr('class', 'x-axis').attr('transform', `translate(0, ${height - margin.bottom})`).call(d3.axisBottom(x).ticks(6).tickPadding(6));
    svg.append('g').attr('class', 'y-axis').attr('transform', `translate(${margin.left}, 0)`).call(d3.axisLeft(y).ticks(5));
};

const createGradient = (svg, id, colorStart, colorEnd) => {
    const defs = svg.append('defs');
    const gradient = defs.append('linearGradient').attr('id', id).attr('x1', '0%').attr('y1', '0%').attr('x2', '0%').attr('y2', '100%');
    gradient.append('stop').attr('offset', '0%').style('stop-color', colorStart).style('stop-opacity', 0.6);
    gradient.append('stop').attr('offset', '100%').style('stop-color', colorEnd).style('stop-opacity', 0.2);
    return `url(#${id})`;
};

const createEffects = (svg) => {
    const defs = svg.append('defs');
    defs.append('filter').attr('id', 'glow').append('feGaussianBlur').attr('stdDeviation', '3');
};

const createLegend = (svg, width, color, text, fontScale) => {
    svg.append('g').attr('class', 'legend').attr('transform', `translate(${width - 100}, 20)`).append('text')
        .attr('x', 20).attr('y', 10).attr('fill', getCSSVariable('--fg')).style('font-size', `${12 * fontScale}px`).text(`${text}: ${color}`);
};

const createScatterLegend = (svg, width, colors, fontScale) => {
    const legend = svg.append('g').attr('class', 'legend').attr('transform', `translate(${width - 220}, 20)`);
    ['Total TF', 'OCM Overall'].forEach((text, i) => {
        legend.append('text').attr('x', i * 140 + 20).attr('y', 10).attr('fill', getCSSVariable('--fg')).style('font-size', `${12 * fontScale}px`).text(`${text}: ${colors[i]}`);
    });
};

const initializeCharts = async () => {
    if (typeof d3 === 'undefined') {
        console.error('D3.js not loaded');
        return;
    }
    createTooltip();
    await drawCharts();
};

const createTooltip = () => {
    let tooltip = d3.select('.tooltip');
    if (!tooltip.node()) {
        tooltip = d3.select('body').append('div').attr('class', 'tooltip').style('position', 'absolute').style('opacity', 0)
            .style('z-index', 9999).style('background', getCSSVariable('--card')).style('color', getCSSVariable('--fg'))
            .style('padding', '0.5rem').style('border-radius', '4px').style('box-shadow', '0 2px 8px rgba(0,0,0,0.15)');
    }
    return tooltip;
};

document.addEventListener('DOMContentLoaded', initializeCharts);
document.querySelector('.theme-toggle')?.addEventListener('click', cycleTheme);
document.querySelector('.refresh-data')?.addEventListener('click', refreshCharts);
document.querySelector('.export-pdf')?.addEventListener('click', exportToPDF);