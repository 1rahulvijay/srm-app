const themes = ['light-theme', 'dark-theme', 'corporate-theme', 'neutral-theme'];
let currentTheme = localStorage.getItem('theme') || 'light-theme';
document.body.className = currentTheme;

const chartConfig = {
    defaultWidth: 350,
    defaultHeight: 240,
    margin: { top: 70, right: 30, bottom: 50, left: 30 },
    animationDuration: 2000,
    mobileBreakpoint: 1366,
    resolutions: {
        '1366': { height: 180, fontScale: 0.8 },
        '1920': { height: 240, fontScale: 1 },
        '2560': { height: 288, fontScale: 1.1 },
        '3440': { height: 312, fontScale: 1.2 },
        '3840': { height: 336, fontScale: 1.3 }
    }
};

const getCSSVariable = (variable) =>
    getComputedStyle(document.documentElement).getPropertyValue(variable).trim();

const getResponsiveDimensions = (containerId) => {
    const container = document.querySelector(containerId);
    const screenWidth = window.innerWidth;
    let width = container ? Math.max(container.clientWidth - 40, chartConfig.defaultWidth) : chartConfig.defaultWidth;
    let height = containerId === '#sankey-chart' ? window.innerHeight * 0.5 : chartConfig.defaultHeight;
    let fontScale = 1;

    for (let res in chartConfig.resolutions) {
        if (screenWidth <= parseInt(res)) {
            height = containerId !== '#sankey-chart' ? chartConfig.resolutions[res].height : height;
            fontScale = chartConfig.resolutions[res].fontScale;
            break;
        }
    }

    return { width, height, fontScale };
};

const fetchData = async () => {
    try {
        const path = window.location.pathname;
        const endpoint = path === '/productivity' ? '/api/productivity_data' :
            path === '/fte' ? '/api/fte_data' :
                path === '/sankey' ? '/api/sankey_data' :
                    '/api/data';
        const response = await fetch(endpoint, { cache: 'no-store' });
        if (!response.ok) throw new Error(`Network response was not ok: ${response.status}`);
        const data = await response.json();
        if (path !== '/sankey' && data.metrics?.current_metrics) {
            const metrics = data.metrics.current_metrics;
            const updateMetric = (id, value, trend, percentChange) => {
                const el = document.getElementById(id);
                if (el) el.innerHTML = `${value} <span class="${trend === '↑' ? 'trend-up' : 'trend-down'}">${trend} (${percentChange?.toFixed(2)}%)</span>`;
            };
            if (path === '/productivity') {
                updateMetric('metric-tasks-completed', metrics.tasks_completed, metrics.trends.tasks_completed_trend, metrics.trends.tasks_completed_percent_change);
                updateMetric('metric-avg-completion-time', metrics.avg_completion_time, metrics.trends.avg_completion_time_trend, metrics.trends.avg_completion_time_percent_change);
                updateMetric('metric-efficiency-rate', `${metrics.efficiency_rate}%`, metrics.trends.efficiency_rate_trend, metrics.trends.efficiency_rate_percent_change);
            } else if (path === '/fte') {
                updateMetric('metric-total-fte', metrics.total_fte, metrics.trends.total_fte_trend, metrics.trends.total_fte_percent_change);
                updateMetric('metric-utilization', `${metrics.utilization}%`, metrics.trends.utilization_trend, metrics.trends.utilization_percent_change);
                updateMetric('metric-overtime-hours', metrics.overtime_hours, metrics.trends.overtime_hours_trend, metrics.trends.overtime_hours_percent_change);
            } else {
                updateMetric('metric-count-id', metrics.count_id, metrics.trends.count_id_trend, metrics.trends.count_id_percent_change);
                updateMetric('metric-count-gf', metrics.count_gf, metrics.trends.count_gf_trend, metrics.trends.count_gf_percent_change);
                updateMetric('metric-count-gfc', metrics.count_gfc, metrics.trends.count_gfc_trend, metrics.trends.count_gfc_percent_change);
            }
        }
        return data;
    } catch (error) {
        console.error('Error fetching data:', error);
        return { lineData: [], barData: [], areaData: [], scatterData: [], nodes: [], links: [], metrics: { current_metrics: {} } };
    }
};

function cycleTheme() {
    const index = (themes.indexOf(currentTheme) + 1) % themes.length;
    currentTheme = themes[index];
    document.body.className = currentTheme;
    localStorage.setItem('theme', currentTheme);
    refreshCharts();
}

const closeDetails = () => document.getElementById('details')?.classList.remove('open');
const switchTab = (id) => {
    document.querySelectorAll('.tab, .tab-content').forEach(el => el.classList.remove('active'));
    document.querySelector(`[onclick="switchTab('${id}')"]`)?.classList.add('active');
    document.getElementById(id)?.classList.add('active');
};

const exportToPDF = async () => {
    try {
        if (!window.jspdf?.jsPDF || !window.html2canvas) throw new Error('Required libraries not loaded');
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'tabloid' });
        const pages = [
            { path: '/', title: 'Home Dashboard' },
            { path: '/productivity', title: 'Productivity Dashboard' },
            { path: '/fte', title: 'FTE Dashboard' },
            { path: '/sankey', title: 'Sankey Dashboard' }
        ];

        for (let i = 0; i < pages.length; i++) {
            const { path, title } = pages[i];
            const iframe = document.createElement('iframe');
            iframe.style.width = '1280px';
            iframe.style.height = '720px';
            iframe.style.position = 'absolute';
            iframe.style.left = '-9999px';
            iframe.src = path;
            document.body.appendChild(iframe);

            await new Promise((resolve) => {
                iframe.onload = () => {
                    const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
                    const style = iframeDoc.createElement('style');
                    style.textContent = `
                        .theme-toggle:hover, .refresh-data:hover, .export-pdf:hover { background: ${getFallbackColor(currentTheme, false)} !important; }
                        .close-details:hover { background: ${getFallbackColor(currentTheme, true)} !important; }
                    `;
                    iframeDoc.head.appendChild(style);

                    const checkCharts = setInterval(() => {
                        const charts = iframeDoc.querySelectorAll('#line-chart, #bar-chart, #area-chart, #scatter-chart, #sankey-chart');
                        if (Array.from(charts).every(c => c.innerHTML && !c.innerHTML.includes('Loading'))) {
                            clearInterval(checkCharts);
                            resolve();
                        }
                    }, 500);
                    setTimeout(() => {
                        clearInterval(checkCharts);
                        resolve();
                    }, 10000);
                };
            });

            const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
            const canvas = await html2canvas(iframeDoc.body, { scale: 2, useCORS: true });
            const imgData = canvas.toDataURL('image/png');
            const pdfWidth = doc.internal.pageSize.getWidth();
            const imgHeight = (canvas.height * pdfWidth) / canvas.width;

            if (i > 0) doc.addPage();
            doc.setFontSize(14);
            doc.text(title, 10, 10);
            doc.addImage(imgData, 'PNG', 10, 20, pdfWidth - 20, Math.min(doc.internal.pageSize.getHeight() - 30, imgHeight));
            document.body.removeChild(iframe);
        }

        doc.save('InsightDash_Dashboard.pdf');
    } catch (error) {
        console.error('Error in exportToPDF:', error);
        alert('Failed to export to PDF: ' + error.message);
    }
};

const getFallbackColor = (theme, isCloseDetails) => {
    const fallbacks = {
        'light-theme': isCloseDetails ? '#649af7' : '#5e97f8',
        'dark-theme': isCloseDetails ? '#86b7fb' : '#7db5fb',
        'corporate-theme': isCloseDetails ? '#527fed' : '#497ee9',
        'neutral-theme': isCloseDetails ? '#8c929c' : '#858b98'
    };
    return fallbacks[theme] || fallbacks['light-theme'];
};

const exportToExcel = () => {
    try {
        const rows = document.querySelectorAll('#data-table-content tr');
        if (rows.length <= 1) throw new Error('No data to export');
        const csv = [...rows].map(row => [...row.children].map(cell => `"${cell.textContent.replace(/"/g, '""')}"`).join(',')).join('\n');
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = 'dashboard_data.csv';
        link.click();
        URL.revokeObjectURL(link.href);
    } catch (error) {
        console.error('Error exporting to CSV:', error);
        alert('Failed to export to CSV. Please ensure the table has data and try again.');
    }
};

const showDetails = (data, type, summary) => {
    if (!data?.length) {
        alert('No data available to display.');
        return;
    }
    const container = document.getElementById('details');
    if (!container) return;
    if (container.classList.contains('open')) {
        container.classList.remove('open');
        return;
    }
    document.getElementById('overview-text').textContent = summary;
    const tableBody = document.querySelector('#data-table-content tbody');
    if (tableBody) {
        tableBody.innerHTML = data.map(d => `<tr><td>${d.label || 'N/A'}</td><td>${type === 'scatter' ? `TF: ${d.total_tf?.toFixed(2) || 'N/A'}, OCM: ${d.ocm_overall?.toFixed(2) || 'N/A'}` : `${(d.value ?? 'N/A').toFixed(2)}`}</td></tr>`).join('');
    }
    switchTab('data-table');
    container.classList.add('open');
};

let isRendering = false;

const drawCharts = async () => {
    if (isRendering) return;
    isRendering = true;
    try {
        const data = await fetchData();
        const primaryColorStart = getCSSVariable('--chart-gradient-start');
        const primaryColorEnd = getCSSVariable('--chart-gradient-end');

        const chartConfigs = {
            '/': [
                { id: '#line-chart', data: data.lineData, title: 'ID Count Trend', color: primaryColorStart, type: 'line' },
                { id: '#bar-chart', data: data.barData, title: 'GF Count by Month', color: primaryColorStart, type: 'bar' },
                { id: '#area-chart', data: data.areaData, title: 'GFC Count Trend', color: primaryColorStart, type: 'lollipop' },
                { id: '#scatter-chart', data: data.scatterData, title: 'ID Distribution', colors: ['#ff5555', '#5555ff'], type: 'scatter' }
            ],
            '/productivity': [
                { id: '#line-chart', data: data.lineData, title: 'Tasks Completed Trend', color: primaryColorStart, type: 'line' },
                { id: '#bar-chart', data: data.barData, title: 'Avg Completion Time by Month', color: primaryColorStart, type: 'bar' },
                { id: '#area-chart', data: data.areaData, title: 'Efficiency Rate Trend', color: primaryColorStart, type: 'lollipop' }
            ],
            '/fte': [
                { id: '#line-chart', data: data.lineData, title: 'Total FTE Trend', color: primaryColorStart, type: 'line' },
                { id: '#bar-chart', data: data.barData, title: 'Utilization by Month', color: primaryColorStart, type: 'bar' },
                { id: '#area-chart', data: data.areaData, title: 'Overtime Hours Trend', color: primaryColorStart, type: 'lollipop' }
            ],
            '/sankey': [
                { id: '#sankey-chart', data, title: 'Client Flow Sankey Diagram', color: primaryColorStart, type: 'sankey' }
            ]
        };

        const charts = chartConfigs[window.location.pathname] || chartConfigs['/'];
        const chartCount = charts.length;

        const chartGrid = document.querySelector('.chart-grid');
        if (chartGrid) {
            chartGrid.innerHTML = '';
            chartGrid.className = 'chart-grid';
            if (chartCount === 4) {
                chartGrid.style.gridTemplateColumns = 'repeat(2, 1fr)';
            } else if (chartCount === 3) {
                chartGrid.style.gridTemplateColumns = '1fr 1fr';
                chartGrid.style.gridTemplateRows = '1fr 1fr';
                chartGrid.style.gridTemplateAreas = '"chart1 chart2" "chart3 chart3"';
            } else if (chartCount === 1) {
                chartGrid.style.gridTemplateColumns = '1fr';
                chartGrid.style.gridTemplateRows = '1fr';
                chartGrid.style.height = '100vh';
            }

            charts.forEach((chart, index) => {
                const container = document.createElement('div');
                container.id = chart.id.replace('#', '');
                container.className = 'card';
                if (chartCount === 3 && index === 2) {
                    container.style.gridArea = 'chart3';
                } else if (chartCount === 4) {
                    container.style.gridArea = `chart${index + 1}`;
                }
                chartGrid.appendChild(container);
            });
        }

        ['#line-chart', '#bar-chart', '#area-chart', '#scatter-chart', '#sankey-chart'].forEach(selector => {
            const container = document.querySelector(selector);
            if (container) container.innerHTML = '';
        });

        for (const chart of charts) {
            try {
                const container = document.querySelector(chart.id);
                if (!container) continue;

                switch (chart.type) {
                    case 'line': drawLineChart(chart.id, chart.data, chart.title, chart.color, primaryColorEnd); break;
                    case 'bar': drawBarChart(chart.id, chart.data, chart.title, chart.color, primaryColorEnd, 0); break;
                    case 'lollipop': drawLollipopChart(chart.id, chart.data, chart.title, chart.color, primaryColorEnd); break;
                    case 'scatter': drawScatterChart(chart.id, chart.data, chart.title, chart.colors[0], chart.colors[1]); break;
                    case 'sankey': drawSankeyChart(chart.id, chart.data, chart.title, chart.color); break;
                }
            } catch (error) {
                console.error(`Error rendering chart ${chart.title}:`, error);
                document.querySelector(chart.id).innerHTML = `<div class="error">Error loading chart</div>`;
            }
        }
    } finally {
        isRendering = false;
    }
};

const refreshCharts = async () => {
    if (isRendering) return;
    ['#line-chart', '#bar-chart', '#area-chart', '#scatter-chart', '#sankey-chart'].forEach(selector => {
        const container = document.querySelector(selector);
        if (container) container.innerHTML = '';
    });
    drawCharts();
};

const drawLineChart = (container, data, title, color, colorEnd) => {
    if (!data?.length) {
        d3.select(container).append('text').attr('x', '50%').attr('y', '50%').attr('text-anchor', 'middle').attr('fill', getCSSVariable('--fg')).text('No data');
        return;
    }
    const { width, height, fontScale } = getResponsiveDimensions(container);
    const svg = d3.select(container).append('svg').attr('viewBox', `0 0 ${width} ${height}`);
    const { margin } = chartConfig;
    const x = d3.scalePoint().domain(data.map(d => d.label)).range([margin.left, width - margin.right]);
    const y = d3.scaleLinear().domain([0, d3.max(data, d => d.value) * 1.2]).range([height - margin.bottom, margin.top]);

    createChartBase(svg, width, height, x, y, fontScale);
    createEffects(svg);
    const gradientId = `lineGradient-${Math.random().toString(36).substr(2, 9)}`;
    const fill = createGradient(svg, gradientId, color, colorEnd);

    const line = d3.line().x(d => x(d.label)).y(d => y(d.value)).curve(d3.curveMonotoneX);
    svg.append('path').datum(data).attr('stroke', color).attr('stroke-width', 2).attr('fill', 'none').attr('d', line)
        .attr('stroke-dasharray', d => d.totalLength).attr('stroke-dashoffset', d => d.totalLength)
        .transition().duration(chartConfig.animationDuration).attr('stroke-dashoffset', 0);

    svg.selectAll('circle').data(data).enter().append('circle')
        .attr('cx', d => x(d.label)).attr('cy', d => y(d.value)).attr('r', 4).attr('fill', color)
        .attr('stroke', '#fff').attr('stroke-width', 1).style('cursor', 'pointer')
        .on('mouseover', (event, d) => {
            d3.select('.tooltip').style('display', 'block').html(`<b>${d.label}</b><br>Value: ${d.value}`).style('left', `${event.pageX + 10}px`).style('top', `${event.pageY - 40}px`).style('opacity', 0.9);
        }).on('mouseout', () => d3.select('.tooltip').style('opacity', 0).style('display', 'none'));

    createLegend(svg, width, color, title.split(' ')[0], fontScale);
    svg.on('click', () => showDetails(data, 'line', `Trend of ${title} over time.`));
};

const drawBarChart = (container, data, title, color, colorEnd, percentChange) => {
    if (!data?.length) {
        d3.select(container).append('text').attr('x', '50%').attr('y', '50%').attr('text-anchor', 'middle').attr('fill', getCSSVariable('--fg')).text('No data');
        return;
    }
    const { width, height, fontScale } = getResponsiveDimensions(container);
    const svg = d3.select(container).append('svg').attr('viewBox', `0 0 ${width} ${height}`);
    const { margin } = chartConfig;
    const x = d3.scaleBand().domain(data.map(d => d.label)).range([margin.left, width - margin.right]).padding(0.1);
    const y = d3.scaleLinear().domain([0, d3.max(data, d => d.value) * 1.2]).range([height - margin.bottom, margin.top]);

    createChartBase(svg, width, height, x, y, fontScale);
    createEffects(svg);
    const gradientId = `barGradient-${Math.random().toString(36).substr(2, 9)}`;
    const fill = createGradient(svg, gradientId, color, colorEnd);

    svg.selectAll('rect').data(data).enter().append('rect')
        .attr('x', d => x(d.label)).attr('y', d => y(0)).attr('width', x.bandwidth()).attr('height', 0)
        .attr('fill', fill).attr('rx', 4).style('cursor', 'pointer')
        .transition().duration(chartConfig.animationDuration).attr('y', d => y(d.value)).attr('height', d => height - margin.bottom - y(d.value));

    createLegend(svg, width, color, title.split(' ')[0], fontScale);
    svg.on('click', () => showDetails(data, 'bar', `Distribution of ${title}. % Change: ${percentChange?.toFixed(2) || 'N/A'}%`));
};

const drawLollipopChart = (container, data, title, color, colorEnd) => {
    if (!data?.length) {
        d3.select(container).append('text').attr('x', '50%').attr('y', '50%').attr('text-anchor', 'middle').attr('fill', getCSSVariable('--fg')).text('No data');
        return;
    }
    const { width, height, fontScale } = getResponsiveDimensions(container);
    const svg = d3.select(container).append('svg').attr('viewBox', `0 0 ${width} ${height}`);
    const { margin } = chartConfig;
    const x = d3.scalePoint().domain(data.map(d => d.label)).range([margin.left, width - margin.right]).padding(0.5);
    const y = d3.scaleLinear().domain([0, d3.max(data, d => d.value) * 1.2]).range([height - margin.bottom, margin.top]);

    createChartBase(svg, width, height, x, y, fontScale);
    createEffects(svg);

    svg.selectAll('line').data(data).enter().append('line')
        .attr('x1', d => x(d.label)).attr('x2', d => x(d.label)).attr('y1', y(0)).attr('y2', y(0))
        .attr('stroke', color).attr('stroke-width', 2)
        .transition().duration(chartConfig.animationDuration).attr('y2', d => y(d.value));

    svg.selectAll('circle').data(data).enter().append('circle')
        .attr('cx', d => x(d.label)).attr('cy', y(0)).attr('r', 0).attr('fill', color)
        .attr('stroke', '#fff').attr('stroke-width', 1).style('cursor', 'pointer')
        .transition().duration(chartConfig.animationDuration).attr('cy', d => y(d.value)).attr('r', 4);

    createLegend(svg, width, color, title.split(' ')[0], fontScale);
    svg.on('click', () => showDetails(data, 'grouped-bar', `Trend of ${title} over time.`));
};

const drawScatterChart = (container, data, title, colorTF, colorOCM) => {
    if (!data?.length) {
        d3.select(container).append('text').attr('x', '50%').attr('y', '50%').attr('text-anchor', 'middle').attr('fill', getCSSVariable('--fg')).text('No data');
        return;
    }
    const { width, height, fontScale } = getResponsiveDimensions(container);
    const svg = d3.select(container).append('svg').attr('viewBox', `0 0 ${width} ${height}`);
    const { margin } = chartConfig;
    const x = d3.scalePoint().domain(data.map(d => d.label)).range([margin.left, width - margin.right]);
    const yTF = d3.scaleLinear().domain([0, d3.max(data, d => d.total_tf || 0) * 1.2]).range([height - margin.bottom, margin.top]);
    const yOCM = d3.scaleLinear().domain([0, d3.max(data, d => d.ocm_overall || 0) * 1.2]).range([height - margin.bottom, margin.top]);

    createChartBase(svg, width, height, x, yTF, fontScale);
    svg.append('g').attr('class', 'y-axis').attr('transform', `translate(${width - margin.right}, 0)`).call(d3.axisRight(yOCM));
    createEffects(svg);

    const lineTF = d3.line().x(d => x(d.label)).y(d => yTF(d.total_tf || 0));
    const lineOCM = d3.line().x(d => x(d.label)).y(d => yOCM(d.ocm_overall || 0));

    svg.append('path').datum(data).attr('stroke', colorTF).attr('stroke-width', 2).attr('fill', 'none').attr('d', lineTF);
    svg.append('path').datum(data).attr('stroke', colorOCM).attr('stroke-width', 2).attr('fill', 'none').attr('d', lineOCM);

    svg.selectAll('.dot-tf').data(data).enter().append('circle')
        .attr('cx', d => x(d.label)).attr('cy', d => yTF(d.total_tf || 0)).attr('r', 4).attr('fill', colorTF)
        .attr('stroke', '#fff').attr('stroke-width', 1).style('cursor', 'pointer');
    svg.selectAll('.dot-ocm').data(data).enter().append('circle')
        .attr('cx', d => x(d.label)).attr('cy', d => yOCM(d.ocm_overall || 0)).attr('r', 4).attr('fill', colorOCM)
        .attr('stroke', '#fff').attr('stroke-width', 1).style('cursor', 'pointer');

    createScatterLegend(svg, width, [colorTF, colorOCM], fontScale);
    svg.on('click', () => showDetails(data, 'scatter', `Distribution of ${title} over time.`));
};

// const drawSankeyChart = (containerId, data, title, color) => {
//     if (!data?.nodes?.length || !data?.links?.length) {
//         d3.select(containerId).append('text').attr('x', '50%').attr('y', '50%').attr('text-anchor', 'middle').style('fill', getCSSVariable('--fg')).text('No data');
//         return;
//     }
//     const { width, height, fontScale } = getResponsiveDimensions(containerId);
//     const svg = d3.select(containerId).append('svg').attr('viewBox', `0 0 ${width} ${height}`).style('width', '100%').style('height', '100%');
//     const { margin } = chartConfig;
//     const sankey = d3.sankey().nodeWidth(20).nodePadding(10).extent([[margin.left, margin.top], [width - margin.right, height - margin.bottom]]);
//     const sankeyData = sankey({ nodes: data