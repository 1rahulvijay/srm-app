const themes = [
    'light-theme', 'dark-theme',
    'corporate-theme', 'neutral-theme',
];

let currentTheme = 'light-theme';
const chartConfig = {
    defaultWidth: 350,
    defaultHeight: 200,
    margin: { top: 70, right: 30, bottom: 30, left: 30 },
    animationDuration: 6000,
    mobileBreakpoint: 768,
    largeScreenBreakpoint: 1920
};

// Utility Functions
const getCSSVariable = (variable) =>
    getComputedStyle(document.documentElement).getPropertyValue(variable).trim();

const getResponsiveDimensions = (containerId) => {
    const container = document.querySelector(containerId);
    const width = container ? Math.max(container.clientWidth - 20, chartConfig.defaultWidth) : chartConfig.defaultWidth;
    const height = window.innerWidth <= chartConfig.mobileBreakpoint ? 180 :
        (window.innerWidth >= chartConfig.largeScreenBreakpoint ? 220 : chartConfig.defaultHeight);
    return { width, height, fontScale: Math.min(1, width / chartConfig.defaultWidth) };
};

// Data Fetching
const fetchData = async () => {
    const spinners = document.querySelectorAll('.loading-spinner');
    spinners.forEach(spinner => spinner.style.display = 'block');

    try {
        const response = await fetch('/api/data', { cache: 'no-store' });
        if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
        const data = await response.json();
        if (!data.metrics?.current_metrics) throw new Error('Invalid data structure');
        const metrics = data.metrics.current_metrics;
        const idCount = document.getElementById('metric-id-count');
        const gfCount = document.getElementById('metric-gf-count');
        const gfcCount = document.getElementById('metric-gfc-count');
        if (idCount) idCount.innerHTML = `${metrics.count_id} <span class="${metrics.trends.count_id_trend === '↑' ? 'trend-up' : 'trend-down'}">${metrics.trends.count_id_trend}</span> (${metrics.trends.count_id_percent_change?.toFixed(2) || 'N/A'}%)`;
        if (gfCount) gfCount.innerHTML = `${metrics.count_gf} <span class="${metrics.trends.count_gf_trend === '↑' ? 'trend-up' : 'trend-down'}">${metrics.trends.count_gf_trend}</span> (${metrics.trends.count_gf_percent_change?.toFixed(2) || 'N/A'}%)`;
        if (gfcCount) gfcCount.innerHTML = `${metrics.count_gfc} <span class="${metrics.trends.count_gfc_trend === '↑' ? 'trend-up' : 'trend-down'}">${metrics.trends.count_gfc_trend}</span> (${metrics.trends.count_gfc_percent_change?.toFixed(2) || 'N/A'}%)`;
        return data || { lineData: [], barData: [], areaData: [], scatterData: [], metrics: {} };
    } catch (error) {
        console.error('Error fetching data:', error);
        alert('Failed to fetch data. Please try again later.');
        return { lineData: [], barData: [], areaData: [], scatterData: [], metrics: {} };
    } finally {
        spinners.forEach(spinner => spinner.style.display = 'none');
    }
};

// Theme and UI Controls
const cycleTheme = () => {
    currentTheme = themes[(themes.indexOf(currentTheme) + 1) % themes.length];
    document.body.className = currentTheme;
    refreshCharts();
};

const refreshCharts = () => {
    document.querySelectorAll('.card svg').forEach(svg => svg.remove());
    drawCharts();
};

const refreshData = async () => {
    document.querySelectorAll('.card svg').forEach(svg => svg.remove());
    await drawCharts();
};

const closeDetails = () => {
    const details = document.getElementById('details');
    if (details) details.classList.remove('open');
};

const switchTab = (id) => {
    document.querySelectorAll('.tab, .tab-content').forEach(el => el.classList.remove('active'));
    const tab = document.querySelector(`[onclick="switchTab('${id}')"]`);
    const content = document.getElementById(id);
    if (tab) tab.classList.add('active');
    if (content) content.classList.add('active');
};

const exportToExcel = () => {
    try {
        const rows = document.querySelectorAll('#data-table-content tr');
        if (rows.length <= 1) throw new Error('No data to export');
        const csv = [...rows].map(row =>
            [...row.children].map(cell => `"${cell.textContent.replace(/"/g, '""')}"`).join(',')
        ).join('\n');
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = 'dashboard_data.csv';
        link.click();
        URL.revokeObjectURL(link.href);
    } catch (error) {
        console.error('Error exporting to CSV:', error);
        alert('Failed to export to CSV. Please ensure the table has data and try again.');
    }
};

// Chart Rendering
const createTooltip = () => {
    d3.select('.tooltip').remove();
    return d3.select('body')
        .append('div')
        .attr('class', 'tooltip')
        .style('position', 'absolute')
        .style('opacity', 0)
        .style('display', 'none')
        .style('pointer-events', 'none')
        .style('z-index', 9999)
        .style('background', getCSSVariable('--card'))
        .style('color', getCSSVariable('--fg'))
        .style('padding', '0.5rem')
        .style('font-size', getCSSVariable('--font-size-base'))
        .style('border-radius', '4px')
        .style('box-shadow', '0 2px 8px rgba(0, 0, 0, 0.15)')
        .style('border', `1px solid ${getCSSVariable('--card-border')}`);
};

const showDetails = (data, type, summary) => {
    if (!data?.length) {
        alert('No data available to display.');
        return;
    }
    const container = document.getElementById('details');
    if (!container) {
        console.error('Details container not found');
        return;
    }
    if (container.classList.contains('open')) {
        container.classList.remove('open');
        return;
    }
    const overview = document.getElementById('overview-text');
    const tableBody = document.querySelector('#data-table-content tbody');
    if (overview) overview.textContent = summary;
    if (tableBody) {
        tableBody.innerHTML = data.map(d => `
            <tr>
                <td>${d.label || 'N/A'}</td>
                <td>${type === 'scatter' ?
                `TF: ${d.total_tf?.toFixed(2) || 'N/A'}, OCM: ${d.ocm_overall?.toFixed(2) || 'N/A'}` :
                type === 'grouped-bar' ?
                    `Baseline: ${d.baseline?.toFixed(2) || 'N/A'}, Growth: ${d.growth?.toFixed(2) || 'N/A'}` :
                    `${(d.value ?? 'N/A').toFixed(2)}`}</td>
            </tr>
        `).join('');
    }
    const alt = d3.select('#alt-chart-content');
    alt.selectAll('*').remove();
    const { width, height } = getResponsiveDimensions('#alt-chart-content');
    const svg = alt.append('svg').attr('viewBox', `0 0 ${width} ${Math.min(height, 180)}`);
    switchTab('data-table');
    container.classList.add('open');
};

const createChartBase = (svg, width, height, x, y, fontScale) => {
    const { margin } = chartConfig;
    svg.append('g')
        .attr('class', 'grid')
        .attr('transform', `translate(0, ${height - margin.bottom})`)
        .call(d3.axisBottom(x).tickSize(-height + margin.top + margin.bottom).tickFormat(''))
        .selectAll('line')
        .attr('stroke', getCSSVariable('--grid'))
        .attr('stroke-opacity', 0.2)
        .attr('stroke-dasharray', '2,2');
    svg.append('g')
        .attr('class', 'grid')
        .attr('transform', `translate(${margin.left}, 0)`)
        .call(d3.axisLeft(y).tickSize(-width + margin.left + margin.right).tickFormat(''))
        .selectAll('line')
        .attr('stroke', getCSSVariable('--grid'))
        .attr('stroke-opacity', 0.2)
        .attr('stroke-dasharray', '2,2');
    svg.append('g')
        .attr('class', 'x-axis')
        .attr('transform', `translate(0, ${height - margin.bottom})`)
        .call(d3.axisBottom(x)
            .ticks(Math.min(10, x.domain().length))
            .tickFormat((d, i) => i % (Math.ceil(x.domain().length / 6)) === 0 ? d : '')
            .tickPadding(6))
        .selectAll('text')
        .attr('fill', getCSSVariable('--fg'))
        .style('font-size', `${10 * fontScale}px`)
        .attr('transform', window.innerWidth <= chartConfig.mobileBreakpoint ? 'rotate(-45)' : 'rotate(0)')
        .style('text-anchor', window.innerWidth <= chartConfig.mobileBreakpoint ? 'end' : 'middle')
        .selectAll('line, path')
        .attr('stroke', getCSSVariable('--fg'))
        .attr('stroke-width', 0.8)
        .attr('stroke-opacity', 0.7);
    svg.append('g')
        .attr('class', 'y-axis')
        .attr('transform', `translate(${margin.left}, 0)`)
        .call(d3.axisLeft(y).ticks(5).tickFormat(d => d.toFixed(0)))
        .selectAll('text')
        .attr('fill', getCSSVariable('--fg'))
        .style('font-size', `${10 * fontScale}px`)
        .selectAll('line, path')
        .attr('stroke', getCSSVariable('--fg'))
        .attr('stroke-width', 0.8)
        .attr('stroke-opacity', 0.7);
};

const createGradient = (svg, id, colorStart, colorEnd) => {
    const defs = svg.append('defs');
    const gradient = defs.append('linearGradient')
        .attr('id', id)
        .attr('x1', '0%')
        .attr('y1', '0%')
        .attr('x2', '0%')
        .attr('y2', '100%');
    gradient.append('stop')
        .attr('offset', '0%')
        .style('stop-color', colorStart)
        .style('stop-opacity', 0.6);
    gradient.append('stop')
        .attr('offset', '100%')
        .style('stop-color', colorEnd)
        .style('stop-opacity', 0.2);
    return `url(#${id})`;
};

const createEffects = (svg) => {
    const defs = svg.append('defs');
    const shadow = defs.append('filter').attr('id', 'drop-shadow').attr('height', '130%');
    shadow.append('feDropShadow')
        .attr('dx', 1)
        .attr('dy', 1)
        .attr('stdDeviation', 3)
        .attr('flood-opacity', 0.4);
    const glow = defs.append('filter').attr('id', 'glow');
    glow.append('feGaussianBlur').attr('stdDeviation', '3').attr('result', 'coloredBlur');
    const feMerge = glow.append('feMerge');
    feMerge.append('feMergeNode').attr('in', 'coloredBlur');
    feMerge.append('feMergeNode').attr('in', 'SourceGraphic');
};

const createLegend = (svg, width, color, text, fontScale, offsetY = 20) => {
    const legend = svg.append('g')
        .attr('class', 'legend')
        .attr('transform', `translate(${width / 2 - 50}, ${offsetY})`)
        .attr('opacity', 0);
    legend.append('rect')
        .attr('width', 12)
        .attr('height', 12)
        .attr('fill', color)
        .attr('filter', 'url(#glow)');
    legend.append('text')
        .attr('x', 60)
        .attr('y', 10)
        .attr('fill', getCSSVariable('--fg'))
        .style('font-size', `${12 * fontScale}px`)
        .text(text);
    legend.transition()
        .duration(800)
        .delay(chartConfig.animationDuration / 2)
        .attr('opacity', 1);
};

const drawCharts = async () => {
    const data = await fetchData();
    const primaryColorStart = '#4a6fa5';
    const primaryColorEnd = '#81a1c1';
    const charts = [
        { id: '#line-chart', data: data.lineData, title: 'ID Count Trend', color: primaryColorStart, colorEnd: primaryColorEnd, type: 'line' },
        { id: '#bar-chart', data: data.barData, title: 'GF Count by Month', color: primaryColorStart, colorEnd: primaryColorEnd, type: 'bar' },
        { id: '#area-chart', data: data.areaData, title: 'GFC Count Trend', color: primaryColorStart, colorEnd: primaryColorEnd, type: 'grouped-bar' },
        { id: '#scatter-chart', data: data.scatterData, title: 'ID Distribution', colors: ['#ff5555', '#5555ff'], type: 'scatter' }
    ];

    charts.forEach(chart => {
        switch (chart.type) {
            case 'line': drawLineChart(chart.id, chart.data, chart.title, chart.color, chart.colorEnd); break;
            case 'bar': drawBarChart(chart.id, chart.data, chart.title, chart.color, chart.colorEnd, data.metrics.current_metrics.trends.count_gf_percent_change); break;
            case 'grouped-bar': drawLollipopChart(chart.id, chart.data, chart.title, chart.color, chart.colorEnd); break;
            case 'scatter': drawScatterChart(chart.id, chart.data, chart.title, chart.colors[0], chart.colors[1]); break;
        }
    });
};

const drawLineChart = (container, data, title, color, colorEnd) => {
    if (!data?.length) {
        d3.select(container).append('text')
            .attr('x', '50%')
            .attr('y', '50%')
            .attr('text-anchor', 'middle')
            .attr('fill', getCSSVariable('--fg'))
            .text('No data available');
        return;
    }
    const { width, height, fontScale } = getResponsiveDimensions(container);
    const svg = d3.select(container).append('svg')
        .attr('viewBox', `0 0 ${width} ${height}`)
        .style('font-size', `${12 * fontScale}px`);
    const { margin } = chartConfig;
    const x = d3.scalePoint().domain(data.map(d => d.label)).range([margin.left, width - margin.right]);
    const y = d3.scaleLinear().domain([0, d3.max(data, d => d.value) * 1.2]).nice().range([height - margin.bottom, margin.top]);

    createChartBase(svg, width, height, x, y, fontScale);
    createEffects(svg);
    const gradientId = `lineGradient-${Math.random().toString(36).substr(2, 9)}`;
    const fill = createGradient(svg, gradientId, color, colorEnd);

    const area = d3.area().x(d => x(d.label)).y0(height - margin.bottom).y1(d => y(d.value)).curve(d3.curveMonotoneX);
    svg.append('path').datum(data).attr('fill', fill).attr('d', area).attr('opacity', 0)
        .transition().duration(chartConfig.animationDuration).ease(d3.easeElastic).attr('opacity', 0.8);

    const line = d3.line().x(d => x(d.label)).y(d => y(d.value)).curve(d3.curveMonotoneX);
    svg.append('path').datum(data).attr('stroke', color).attr('stroke-width', 3).attr('fill', 'none').attr('d', line)
        .attr('stroke-dasharray', function () { return this.getTotalLength(); })
        .attr('stroke-dashoffset', function () { return this.getTotalLength(); })
        .transition().duration(chartConfig.animationDuration).ease(d3.easeElastic)
        .attr('stroke-dashoffset', 0);

    svg.selectAll('circle').data(data).enter().append('circle')
        .attr('cx', d => x(d.label)).attr('cy', d => y(d.value)).attr('r', 0).attr('fill', color)
        .attr('stroke', '#fff').attr('stroke-width', 2).style('cursor', 'pointer')
        .attr('filter', 'url(#glow)')
        .on('mouseover', (event, d) => {
            const tooltipWidth = d3.select('.tooltip').node()?.offsetWidth || 200;
            const xPos = Math.min(event.pageX + 10, window.innerWidth - tooltipWidth - 20);
            d3.select('.tooltip').style('display', 'block')
                .html(`<b>${d.label}</b><br>Value: ${d.value?.toFixed(1) || 'N/A'}<br>Trend: ${d.value > (data[data.indexOf(d) - 1]?.value || 0) ? '↑' : '↓'}`)
                .style('left', `${xPos}px`).style('top', `${Math.max(event.pageY - 40, 20)}px`)
                .transition().duration(200).ease(d3.easeElastic).style('opacity', 0.9);
        })
        .on('mouseout', () => d3.select('.tooltip').transition().duration(300).ease(d3.easeElastic).style('opacity', 0)
            .on('end', () => d3.select('.tooltip').style('display', 'none')))
        .transition().duration(chartConfig.animationDuration / 2).delay((d, i) => i * 300).ease(d3.easeElastic).attr('r', 6);

    svg.selectAll('.data-label').data(data).enter().append('text')
        .attr('class', 'data-label')
        .attr('x', d => x(d.label))
        .attr('y', d => y(d.value) - 10)
        .attr('fill', getCSSVariable('--fg'))
        .attr('text-anchor', 'middle')
        .style('font-size', `${10 * fontScale}px`)
        .style('opacity', 0)
        .text(d => d.value.toFixed(0))
        .transition().duration(chartConfig.animationDuration / 2).delay((d, i) => i * 300).ease(d3.easeElastic).style('opacity', 1);

    createLegend(svg, width, color, 'ID Count', fontScale);

    svg.on('click', () => showDetails(data, 'line', `Trend of ${title} over time.`));
};

const drawBarChart = (container, data, title, color, colorEnd, percentChange) => {
    if (!data?.length) {
        d3.select(container).append('text')
            .attr('x', '50%')
            .attr('y', '50%')
            .attr('text-anchor', 'middle')
            .attr('fill', getCSSVariable('--fg'))
            .text('No data available');
        return;
    }
    const { width, height, fontScale } = getResponsiveDimensions(container);
    const svg = d3.select(container).append('svg')
        .attr('viewBox', `0 0 ${width} ${height}`)
        .style('font-size', `${12 * fontScale}px`);
    const { margin } = chartConfig;
    const x = d3.scaleBand().domain(data.map(d => d.label)).range([margin.left, width - margin.right]).padding(0.25);
    const y = d3.scaleLinear().domain([0, d3.max(data, d => d.value) * 1.2]).nice().range([height - margin.bottom, margin.top]);

    createChartBase(svg, width, height, x, y, fontScale);
    createEffects(svg);
    const gradientId = `barGradient-${Math.random().toString(36).substr(2, 9)}`;
    const fill = createGradient(svg, gradientId, color, colorEnd);

    svg.selectAll('rect').data(data).enter().append('rect')
        .attr('x', d => x(d.label)).attr('y', d => y(0)).attr('width', x.bandwidth()).attr('height', 0)
        .attr('fill', fill).attr('rx', 6).attr('ry', 6).style('cursor', 'pointer')
        .attr('filter', 'url(#glow)')
        .on('mouseover', (event, d) => {
            const tooltipWidth = d3.select('.tooltip').node()?.offsetWidth || 200;
            const xPos = Math.min(event.pageX + 10, window.innerWidth - tooltipWidth - 20);
            const changeText = d === data[0] ? `<br>% Change: ${percentChange?.toFixed(2) || 'N/A'}%` : '';
            d3.select('.tooltip').style('display', 'block')
                .html(`<b>${d.label}</b><br>Value: ${d.value?.toFixed(1) || 'N/A'}${changeText}<br>Trend: ${d.value > (data[data.indexOf(d) - 1]?.value || 0) ? '↑' : '↓'}`)
                .style('left', `${xPos}px`).style('top', `${Math.max(event.pageY - 40, 20)}px`)
                .transition().duration(200).ease(d3.easeElastic).style('opacity', 0.9);
        })
        .on('mouseout', () => d3.select('.tooltip').transition().duration(300).ease(d3.easeElastic).style('opacity', 0)
            .on('end', () => d3.select('.tooltip').style('display', 'none')))
        .transition().duration(chartConfig.animationDuration).delay((d, i) => i * 300).ease(d3.easeElastic)
        .attr('y', d => y(d.value)).attr('height', d => height - margin.bottom - y(d.value));

    svg.selectAll('.data-label').data(data).enter().append('text')
        .attr('class', 'data-label')
        .attr('x', d => x(d.label) + x.bandwidth() / 2)
        .attr('y', d => y(d.value) - 5)
        .attr('fill', getCSSVariable('--fg'))
        .attr('text-anchor', 'middle')
        .style('font-size', `${10 * fontScale}px`)
        .style('opacity', 0)
        .text(d => d.value.toFixed(0))
        .transition().duration(chartConfig.animationDuration / 2).delay((d, i) => i * 300).ease(d3.easeElastic).style('opacity', 1);

    createLegend(svg, width, color, 'GF Count', fontScale);

    svg.on('click', () => showDetails(data, 'bar', `Distribution of ${title} over time. Current month % change: ${percentChange?.toFixed(2) || 'N/A'}%`));
};

const drawLollipopChart = (container, data, title, color, colorEnd) => {
    if (!data?.length) {
        d3.select(container).append('text')
            .attr('x', '50%').attr('y', '50%')
            .attr('text-anchor', 'middle')
            .attr('fill', getCSSVariable('--fg'))
            .text('No data available');
        return;
    }
    const { width, height, fontScale } = getResponsiveDimensions(container);
    const svg = d3.select(container).append('svg')
        .attr('viewBox', `0 0 ${width} ${height}`)
        .style('font-size', `${12 * fontScale}px`);

    const { margin } = chartConfig;
    const x = d3.scalePoint()
        .domain(data.map(d => d.label))
        .range([margin.left + 1, width - margin.right - 1])
        .padding(0.5);
    const y = d3.scaleLinear().domain([0, d3.max(data, d => d.value) * 1.2]).nice()
        .range([height - margin.bottom, margin.top]);

    createChartBase(svg, width, height, x, y, fontScale);
    createEffects(svg);

    svg.selectAll('line.stem')
        .data(data).enter()
        .append('line')
        .attr('class', 'stem')
        .attr('x1', d => x(d.label)).attr('x2', d => x(d.label))
        .attr('y1', y(0)).attr('y2', y(0))
        .attr('stroke', color)
        .attr('stroke-width', 2)
        .transition().duration(chartConfig.animationDuration)
        .ease(d3.easeBounce)
        .attr('y2', d => y(d.value));

    svg.selectAll('circle.head')
        .data(data).enter()
        .append('circle')
        .attr('class', 'head')
        .attr('cx', d => x(d.label))
        .attr('cy', y(0))
        .attr('r', 0)
        .attr('fill', color)
        .attr('stroke', '#fff')
        .attr('stroke-width', 2)
        .attr('filter', 'url(#glow)')
        .transition().duration(chartConfig.animationDuration)
        .delay((d, i) => i * 100)
        .ease(d3.easeElasticOut)
        .attr('cy', d => y(d.value))
        .attr('r', 6);

    svg.selectAll('.data-label').data(data).enter().append('text')
        .attr('class', 'data-label')
        .attr('x', d => x(d.label))
        .attr('y', d => y(d.value) - 10)
        .attr('fill', getCSSVariable('--fg'))
        .attr('text-anchor', 'middle')
        .style('font-size', `${10 * fontScale}px`)
        .style('opacity', 0)
        .text(d => d.value.toFixed(0))
        .transition().duration(chartConfig.animationDuration / 2).delay((d, i) => i * 300).ease(d3.easeElastic).style('opacity', 1);

    svg.selectAll('circle.head')
        .on('mouseover', (event, d) => {
            const tooltipWidth = d3.select('.tooltip').node()?.offsetWidth || 200;
            const xPos = Math.min(event.pageX + 10, window.innerWidth - tooltipWidth - 20);
            d3.select('.tooltip').style('display', 'block')
                .html(`<b>${d.label}</b><br>Value: ${d.value?.toFixed(1) || 'N/A'}`)
                .style('left', `${xPos}px`).style('top', `${Math.max(event.pageY - 40, 20)}px`)
                .transition().duration(200).ease(d3.easeElastic).style('opacity', 0.9);
        })
        .on('mouseout', () => d3.select('.tooltip').transition().duration(300).ease(d3.easeElastic).style('opacity', 0)
            .on('end', () => d3.select('.tooltip').style('display', 'none')));

    createLegend(svg, width, color, 'GFC Count', fontScale);
    svg.on('click', () => showDetails(data, 'lollipop', `GFC Count Trend over time`));
};

const drawScatterChart = (container, data, title, colorTF, colorOCM) => {
    if (!data?.length) {
        d3.select(container).append('text')
            .attr('x', '50%')
            .attr('y', '50%')
            .attr('text-anchor', 'middle')
            .attr('fill', getCSSVariable('--fg'))
            .text('No data available');
        return;
    }
    const { width, height, fontScale } = getResponsiveDimensions(container);
    const svg = d3.select(container).append('svg')
        .attr('viewBox', `0 0 ${width} ${height}`)
        .style('font-size', `${12 * fontScale}px`);
    const { margin } = chartConfig;
    const x = d3.scalePoint().domain(data.map(d => d.label)).range([margin.left, width - margin.right]);
    const yTF = d3.scaleLinear().domain([0, d3.max(data, d => d.total_tf || 0) * 1.2]).nice().range([height - margin.bottom, margin.top]);
    const yOCM = d3.scaleLinear().domain([0, d3.max(data, d => d.ocm_overall || 0) * 1.2]).nice().range([height - margin.bottom, margin.top]);

    createChartBase(svg, width, height, x, yTF, fontScale);
    svg.append('g').attr('class', 'y-axis').attr('transform', `translate(${width - margin.right}, 0)`)
        .call(d3.axisRight(yOCM).ticks(5).tickFormat(d => d.toFixed(0)))
        .selectAll('text').attr('fill', colorOCM).style('font-size', `${10 * fontScale}px`)
        .selectAll('line, path')
        .attr('stroke', colorOCM)
        .attr('stroke-width', 0.8)
        .attr('stroke-opacity', 0.7);

    createEffects(svg);

    const lineTF = d3.line().x(d => x(d.label)).y(d => yTF(d.total_tf || 0)).curve(d3.curveMonotoneX);
    const lineOCM = d3.line().x(d => x(d.label)).y(d => yOCM(d.ocm_overall || 0)).curve(d3.curveMonotoneX);

    const tfLine = svg.append('path').datum(data).attr('class', 'tf-line').attr('stroke', colorTF).attr('stroke-width', 3).attr('fill', 'none').attr('d', lineTF)
        .attr('stroke-dasharray', function () { return this.getTotalLength(); })
        .attr('stroke-dashoffset', function () { return this.getTotalLength(); })
        .transition().duration(chartConfig.animationDuration).ease(d3.easeElastic).attr('stroke-dashoffset', 0);

    const ocmLine = svg.append('path').datum(data).attr('class', 'ocm-line').attr('stroke', colorOCM).attr('stroke-width', 3).attr('fill', 'none').attr('d', lineOCM)
        .attr('stroke-dasharray', function () { return this.getTotalLength(); })
        .attr('stroke-dashoffset', function () { return this.getTotalLength(); })
        .transition().duration(chartConfig.animationDuration).ease(d3.easeElastic).attr('stroke-dashoffset', 0);

    let tfVisible = true, ocmVisible = true;
    const tfDots = svg.selectAll('.dot-tf').data(data).enter().append('circle')
        .attr('class', 'dot-tf').attr('cx', d => x(d.label)).attr('cy', d => yTF(d.total_tf || 0)).attr('r', 0)
        .attr('fill', colorTF).attr('stroke', '#fff').attr('stroke-width', 2).style('cursor', 'pointer')
        .attr('filter', 'url(#glow)')
        .on('mouseover', (event, d) => {
            const tooltipWidth = d3.select('.tooltip').node()?.offsetWidth || 200;
            const xPos = Math.min(event.pageX + 10, window.innerWidth - tooltipWidth - 20);
            d3.select('.tooltip').style('display', 'block')
                .html(`<b>${d.label}</b><br>Total TF: ${d.total_tf?.toFixed(1) || 'N/A'}`)
                .style('left', `${xPos}px`).style('top', `${Math.max(event.pageY - 40, 20)}px`)
                .transition().duration(200).ease(d3.easeElastic).style('opacity', 0.9);
        })
        .on('mouseout', () => d3.select('.tooltip').transition().duration(300).ease(d3.easeElastic).style('opacity', 0)
            .on('end', () => d3.select('.tooltip').style('display', 'none')))
        .transition().duration(chartConfig.animationDuration / 2).delay((d, i) => i * 300).ease(d3.easeElastic).attr('r', 5);

    const ocmDots = svg.selectAll('.dot-ocm').data(data).enter().append('circle')
        .attr('class', 'dot-ocm').attr('cx', d => x(d.label)).attr('cy', d => yOCM(d.ocm_overall || 0)).attr('r', 0)
        .attr('fill', colorOCM).attr('stroke', '#fff').attr('stroke-width', 2).style('cursor', 'pointer')
        .attr('filter', 'url(#glow)')
        .on('mouseover', (event, d) => {
            const tooltipWidth = d3.select('.tooltip').node()?.offsetWidth || 200;
            const xPos = Math.min(event.pageX + 10, window.innerWidth - tooltipWidth - 20);
            d3.select('.tooltip').style('display', 'block')
                .html(`<b>${d.label}</b><br>OCM Overall: ${d.ocm_overall?.toFixed(1) || 'N/A'}`)
                .style('left', `${xPos}px`).style('top', `${Math.max(event.pageY - 40, 20)}px`)
                .transition().duration(200).ease(d3.easeElastic).style('opacity', 0.9);
        })
        .on('mouseout', () => d3.select('.tooltip').transition().duration(300).ease(d3.easeElastic).style('opacity', 0)
            .on('end', () => d3.select('.tooltip').style('display', 'none')))
        .transition().duration(chartConfig.animationDuration / 2).delay((d, i) => i * 300).ease(d3.easeElastic).attr('r', 5);

    svg.append('g').attr('class', 'legend').attr('transform', `translate(${width / 2 - 50}, ${margin.top - 50})`)
        .call(g => {
            const tfLegend = g.append('g').attr('class', 'legend-item').style('cursor', 'pointer')
                .on('click', () => {
                    tfVisible = !tfVisible;
                    tfLine.attr('opacity', tfVisible ? 1 : 0);
                    tfDots.attr('opacity', tfVisible ? 1 : 0);
                    tfLegend.select('rect').attr('opacity', tfVisible ? 1 : 0.3);
                });
            tfLegend.append('rect').attr('width', 12).attr('height', 12).attr('fill', colorTF).attr('filter', 'url(#glow)');
            tfLegend.append('text').attr('x', 60).attr('y', 10).attr('fill', getCSSVariable('--fg')).style('font-size', `${12 * fontScale}px`).text('Total TF');

            const ocmLegend = g.append('g').attr('class', 'legend-item').attr('transform', 'translate(0, 20)').style('cursor', 'pointer')
                .on('click', () => {
                    ocmVisible = !ocmVisible;
                    ocmLine.attr('opacity', ocmVisible ? 1 : 0);
                    ocmDots.attr('opacity', ocmVisible ? 1 : 0);
                    ocmLegend.select('rect').attr('opacity', ocmVisible ? 1 : 0.3);
                });
            ocmLegend.append('rect').attr('width', 12).attr('height', 12).attr('fill', colorOCM).attr('filter', 'url(#glow)');
            ocmLegend.append('text').attr('x', 60).attr('y', 10).attr('fill', getCSSVariable('--fg')).style('font-size', `${12 * fontScale}px`).text('OCM Overall');
        });

    svg.on('click', () => showDetails(data, 'scatter', `Distribution of ${title} over time.`));
};

// Event Handling
const debounce = (func, wait) => {
    let timeout;
    return (...args) => {
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(this, args), wait);
    };
};

const initializeCharts = () => {
    createTooltip();
    refreshCharts();
};

document.addEventListener('DOMContentLoaded', initializeCharts);
window.addEventListener('resize', debounce(initializeCharts, 150));